﻿namespace SmartACDeviceAPI.Models
{
    public class UserAuthorizationModel
    { 
        public string Username { get; set; }

        public string Password { get; set;  }
    }
}
