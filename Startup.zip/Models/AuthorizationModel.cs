﻿namespace SmartACDeviceAPI.Models
{
    public class AuthorizationModel
    { 
        public string SerialNumber { get; set; }

        public string Secret { get; set;  }
    }
}
