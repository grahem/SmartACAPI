﻿namespace SmartACDeviceAPI
{
    internal class AppSettings
    {

        public string Secret { get; set; }
    }
}